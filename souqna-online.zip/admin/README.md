# لوحة الإدارة

النسخة الحالية تضع أساس لوحة الإدارة في Backend:
- GET /api/admin/ads
- PATCH /api/admin/ads/:id

الواجهة الإدارية الكاملة يمكن فصلها كتطبيق React/Next.js في المرحلة التالية.
